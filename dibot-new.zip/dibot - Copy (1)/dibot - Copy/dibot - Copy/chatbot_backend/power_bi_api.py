import requests
import msal
import json
import os
import pandas as pd
import random

from dotenv import load_dotenv
load_dotenv()

# Azure AD and Power BI API configuration
CLIENT_ID = os.getenv('POWERBI_CLIENT_ID')
TENANT_ID = os.getenv('POWERBI_TENANT_ID')
CLIENT_SECRET = os.getenv('POWERBI_CLIENT_SECRET')
WORKSPACE_ID = os.getenv('POWERBI_WORKSPACE_ID')
DATASET_ID = os.getenv('POWERBI_DATASET_ID')

# AUTHORITY = f'https://login.microsoftonline.com/{tenant_name}'
# SCOPE = ['https://analysis.windows.net/powerbi/api/.default']
# POWER_BI_API_URL = 'https://api.powerbi.com/v1.0/myorg'

# # Create a MSAL confidential client
# client = msal.ConfidentialClientApplication(
#     CLIENT_ID,
#     authority=AUTHORITY,
#     client_credential=CLIENT_SECRET
# )

# Acquire a token
# token_response = client.acquire_token_for_client(scopes=SCOPE)
# access_token = token_response['access_token']

# Function to get the dataset metadata
import random

# Function to get dummy dataset metadata
def get_dataset_metadata(workspace_id, dataset_id):
    # Dummy metadata
    metadata = {
        'id': dataset_id,
        'name': 'Dummy Dataset',
        'workspace_id': workspace_id,
        'createdDate': '2024-01-01',
        'modifiedDate': '2024-07-01',
        'tables': [
            {
                'name': 'Overall',
                'columns': ['DISCIPLINE', 'Value', 'Month-yr', 'EMP Monthly Count']
            }
        ]
    }
    return metadata

# Function to execute a DAX query and return a random DAX query
def execute_dax_query(workspace_id, dataset_id, query):
    dax_list = [
        '''Evaluate SUMMARIZE(FILTER(Overall,Overall[DISCIPLINE]="HSE"),Overall[DISCIPLINE],"Manhours",SUM(Overall[Value]))''',
        '''Evaluate SUMMARIZE(Overall,"Manhours",SUM(Overall[Value]))''',
        '''Evaluate SUMMARIZE(FILTER(Overall,Overall[Month-yr]="Apr-24"),"Apr-24(Manhours)",SUM(Overall[Value]))''',
        '''Evaluate SUMMARIZE(FILTER(Overall,Overall[Month-yr]="Apr-24"),Overall[DISCIPLINE],"Apr-24(ManPower)",[EMP Monthly Count])''',
        '''Evaluate SUMMARIZE(FILTER(Overall,Overall[DISCIPLINE]="CIVIL"),Overall[DISCIPLINE],"Manhours",SUM(Overall[Value]))''',
        '''Evaluate SUMMARIZE(FILTER(Overall,Overall[DISCIPLINE]="ELECTRICAL" && Overall[Month-yr]="Apr-24"),Overall[DISCIPLINE],Overall[Month-yr],"Manhours",SUM(Overall[Value]))'''
    ]
    
    # Return one random element from the DAX query list
    return random.choice(dax_list)

    # dataframe dummy of three columns two rows
def dataframe():
    data = {
        'Column1': ['Row1_Value1', 'Row2_Value1'],
        'Column2': ['Row1_Value2', 'Row2_Value2'],
        'Column3': ['Row1_Value3', 'Row2_Value3']
    }
    df = pd.DataFrame(data)
    return df
  
# # Retrieve dataset metadata
# dataset_metadata = get_dataset_metadata(WORKSPACE_ID, DATASET_ID)
# print(json.dumps(dataset_metadata, indent=4))

# # Execute a DAX query
# query = "EVALUATE SUMMARIZE('Sales', 'Sales'[Product], 'Sales'[Amount])"
# query1= 'EVALUATE SUMMARIZE(FILTER(Overall,Overall[DISCIPLINE]="COMMISSIONING"&&Overall[Cutoff]>DATE(2023,11,01)),Overall[DISCIPLINE],Overall[Month-yr],"Manhours",SUM(Overall[Value]))'
# query_result = execute_dax_query(WORKSPACE_ID, DATASET_ID, query1)
# print(json.dumps(query_result, indent=4))
